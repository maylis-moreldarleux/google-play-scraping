from enum import Enum


class Sort(int, Enum):
    NEWEST = 2
    MOST_RELEVANT = 1
