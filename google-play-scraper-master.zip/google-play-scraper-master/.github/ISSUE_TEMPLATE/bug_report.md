---
name: Bug report
about: Create a report to help us improve
title: "[BUG] "
labels: ''
assignees: JoMingyu

---

**Library version**


**Describe the bug**
A description of what the bug is.

**Code**
Copy and paste the code that have issue.

```
```

**Expected behavior**
A description of what you expected to happen.

**Additional context**
Add any other context about the problem here.
